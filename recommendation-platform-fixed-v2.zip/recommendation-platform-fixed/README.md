# Recommendation Platform (NestJS + Prisma + PostgreSQL)

This project combines the recommendation-related user stories into one NestJS API:

1. Store raw listening/like/follow/skip events.
2. Rebuild user genre/artist affinities and track popularity from raw events.
3. Store immutable, versioned aggregate snapshots; only switch the active version after validation succeeds.
4. Roll back the active aggregate version to a prior successful rebuild.
5. Save immutable per-user candidate snapshots for stable **My Mix** results.
6. Retrieve active aggregates, user affinities, rebuild status and saved snapshots.
7. Delete expired candidate snapshots without deleting raw event history.

## Requirements
- Node.js 20+
- PostgreSQL 14+ (locally installed is fine)
- npm

## Setup (PowerShell)
Run from the folder containing `package.json`:

```powershell
Copy-Item .env.example .env
notepad .env
```

Change `YOUR_PASSWORD` in `DATABASE_URL` to your PostgreSQL `postgres` user's real password. Create the database if it does not exist:

```sql
CREATE DATABASE recommendation_db;
```

Then run:

```powershell
npm install
npx prisma validate
npx prisma generate
npx prisma migrate dev --name init
npm run build
npm test
npm run start:dev
```

If `postgres` password is unknown, reset it through pgAdmin after connecting with an account that has permission, or use the PostgreSQL installer/admin account recovery steps. Do not put a guessed password into `.env`.

The API listens on `http://localhost:3000/api`. If port 3000 is busy, set `PORT=3001` in `.env` and restart.

## API examples

### 1. Add a raw event
```http
POST /api/recommendations/events
Content-Type: application/json

{
  "userId": "user-1",
  "trackId": "track-1",
  "title": "Night Drive",
  "eventType": "LISTEN",
  "genre": "Electronic",
  "artist": "Example Artist"
}
```
Event types: `LISTEN`, `LIKE`, `FOLLOW`, `SKIP`. Weights are listen=1, like=3, follow=4, skip=-1.

### 2. Rebuild aggregates from raw events
```http
POST /api/recommendations/aggregates/rebuild
Content-Type: application/json

{ "requestedBy": "manual" }
```
Raw events are preserved. The service creates a new version, validates event counters, and saves immutable snapshots in a transaction. The active version changes only after successful validation; a slower older rebuild cannot replace a newer active version. Reads of user affinities follow the active snapshot version, including after rollback.

### 3. Read active aggregate version and aggregates
```http
GET /api/recommendations/aggregates/active-version
GET /api/recommendations/aggregates
GET /api/recommendations/aggregates?userId=user-1
GET /api/recommendations/aggregates/users/user-1/affinities
GET /api/recommendations/rebuilds/REBUILD_ID
```

### 4. Roll back to a successful version
```http
POST /api/recommendations/aggregates/rollback/1
```

### 5. Save a stable My Mix snapshot
```http
POST /api/recommendations/snapshots
Content-Type: application/json

{
  "userId": "user-1",
  "algorithmVersion": "v1",
  "ttlHours": 24,
  "items": [
    { "trackId": "track-1", "score": 0.98 },
    { "trackId": "track-2", "score": 0.87 }
  ]
}
```

Read a snapshot by ID:
```http
GET /api/recommendations/snapshots/SNAPSHOT_ID
```

Get all unexpired snapshots for My Mix:
```http
GET /api/recommendations/users/user-1/my-mix
```

Clean expired snapshots:
```http
DELETE /api/recommendations/snapshots/expired
```

## Notes
- Candidate snapshots are immutable after creation through the public API.
- Raw events are never removed by aggregate rebuilds or snapshot cleanup.
- Production deployments should add authentication/authorization, request rate limits, pagination for large aggregate results, and a scheduled job for cleanup. `npm run lint` is not configured in this starter; use `npm run build` and `npm test` for the included checks.
