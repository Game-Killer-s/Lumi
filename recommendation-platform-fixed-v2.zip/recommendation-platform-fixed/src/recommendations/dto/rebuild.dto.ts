import { IsOptional, IsString, MaxLength } from 'class-validator';
export class RebuildDto {
  @IsOptional() @IsString() @MaxLength(128)
  requestedBy?: string;
}
