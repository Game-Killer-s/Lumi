import { IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class CreateEventDto {
  @IsString() @MinLength(1) @MaxLength(128)
  userId!: string;

  @IsString() @MinLength(1) @MaxLength(128)
  trackId!: string;

  @IsIn(['LISTEN', 'LIKE', 'FOLLOW', 'SKIP'])
  eventType!: 'LISTEN' | 'LIKE' | 'FOLLOW' | 'SKIP';

  @IsOptional() @IsString() @MaxLength(128)
  genre?: string;

  @IsOptional() @IsString() @MaxLength(128)
  artist?: string;

  @IsOptional() @IsString() @MaxLength(255)
  title?: string;
}
