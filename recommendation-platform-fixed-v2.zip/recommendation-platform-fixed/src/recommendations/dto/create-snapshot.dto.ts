import { Type } from 'class-transformer';
import { ArrayMaxSize, ArrayMinSize, IsArray, IsInt, IsNumber, IsOptional, IsString, Max, MaxLength, Min, ValidateNested } from 'class-validator';

export class SnapshotItemDto {
  @IsString() @MaxLength(128)
  trackId!: string;

  @Type(() => Number) @IsNumber({ allowNaN: false, allowInfinity: false })
  score!: number;
}

export class CreateSnapshotDto {
  @IsString() @MaxLength(128)
  userId!: string;

  @IsOptional() @IsString() @MaxLength(64)
  algorithmVersion?: string;

  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(8760)
  ttlHours?: number;

  @IsArray() @ArrayMinSize(1) @ArrayMaxSize(500)
  @ValidateNested({ each: true }) @Type(() => SnapshotItemDto)
  items!: SnapshotItemDto[];
}
