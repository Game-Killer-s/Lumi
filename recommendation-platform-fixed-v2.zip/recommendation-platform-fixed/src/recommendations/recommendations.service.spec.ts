import { RecommendationsService } from './recommendations.service';

describe('RecommendationsService', () => {
  it('uses deterministic event weights', () => {
    const service = new RecommendationsService({} as any);
    expect((service as any).eventWeight('LISTEN')).toBe(1);
    expect((service as any).eventWeight('LIKE')).toBe(3);
    expect((service as any).eventWeight('FOLLOW')).toBe(4);
    expect((service as any).eventWeight('SKIP')).toBe(-1);
  });

  it('returns empty affinities before the first successful rebuild', async () => {
    const service = new RecommendationsService({} as any);
    jest.spyOn(service, 'activeVersion').mockResolvedValue({
      id: 1, version: 0, updatedAt: null,
    } as any);

    await expect(service.userAffinities('user-1')).resolves.toEqual({
      userId: 'user-1', version: 0, genres: [], artists: [],
    });
  });

  it('reads user affinities from the active immutable version', async () => {
    const prisma = {
      activeAggregateVersion: { findUnique: jest.fn().mockResolvedValue({ id: 1, version: 2, updatedAt: new Date() }) },
      rebuildRun: { findUnique: jest.fn().mockResolvedValue({ id: 'run-2', status: 'SUCCEEDED' }) },
      genreAffinitySnapshot: {
        findMany: jest.fn().mockResolvedValue([
          { id: 'g1', rebuildId: 'run-2', userId: 'user-1', genre: 'Electronic', score: 3, sourceCount: 1 },
        ]),
      },
      artistAffinitySnapshot: { findMany: jest.fn().mockResolvedValue([]) },
    };
    const service = new RecommendationsService(prisma as any);

    await expect(service.userAffinities('user-1')).resolves.toEqual({
      userId: 'user-1',
      version: 2,
      genres: [{ id: 'g1', userId: 'user-1', genre: 'Electronic', score: 3, sourceCount: 1 }],
      artists: [],
    });
    expect(prisma.genreAffinitySnapshot.findMany).toHaveBeenCalledWith({
      where: { rebuildId: 'run-2', userId: 'user-1' },
      orderBy: [{ score: 'desc' }, { genre: 'asc' }],
    });
  });
});
