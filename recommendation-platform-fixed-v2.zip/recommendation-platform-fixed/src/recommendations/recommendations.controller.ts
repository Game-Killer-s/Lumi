import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { CreateEventDto } from './dto/create-event.dto';
import { CreateSnapshotDto } from './dto/create-snapshot.dto';
import { RebuildDto } from './dto/rebuild.dto';
import { RecommendationsService } from './recommendations.service';

@Controller('recommendations')
export class RecommendationsController {
  constructor(private readonly service: RecommendationsService) {}

  @Post('events')
  addEvent(@Body() dto: CreateEventDto) { return this.service.addEvent(dto); }

  @Post('aggregates/rebuild')
  rebuild(@Body() dto: RebuildDto) { return this.service.rebuild(dto.requestedBy); }

  @Get('aggregates')
  aggregates(@Query('userId') userId?: string) { return this.service.aggregates(userId); }

  @Get('aggregates/active-version')
  activeVersion() { return this.service.activeVersion(); }

  @Post('aggregates/rollback/:version')
  rollback(@Param('version', ParseIntPipe) version: number) { return this.service.rollback(version); }

  @Get('aggregates/users/:userId/affinities')
  userAffinities(@Param('userId') userId: string) { return this.service.userAffinities(userId); }

  @Get('rebuilds/:id')
  rebuildStatus(@Param('id') id: string) { return this.service.rebuildStatus(id); }

  @Post('snapshots')
  createSnapshot(@Body() dto: CreateSnapshotDto) { return this.service.createSnapshot(dto); }

  @Get('snapshots/:id')
  getSnapshot(@Param('id') id: string) { return this.service.getSnapshot(id); }

  @Get('users/:userId/my-mix')
  myMix(@Param('userId') userId: string) { return this.service.getUserSnapshots(userId); }

  @Get('users/:userId/snapshots')
  userSnapshots(@Param('userId') userId: string) { return this.service.getUserSnapshots(userId); }

  @Delete('snapshots/expired')
  cleanupSnapshots() { return this.service.cleanupSnapshots(); }
}
