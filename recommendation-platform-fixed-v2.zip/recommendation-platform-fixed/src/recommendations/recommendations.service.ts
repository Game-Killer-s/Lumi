import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { EventType, RebuildStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateEventDto } from './dto/create-event.dto';
import { CreateSnapshotDto } from './dto/create-snapshot.dto';

type Counter = {
  userId: string; key: string; score: number;
  listenCount: number; likeCount: number; followCount: number; sourceCount: number;
};

@Injectable()
export class RecommendationsService {
  constructor(private readonly prisma: PrismaService) {}

  async addEvent(dto: CreateEventDto) {
    const userId = dto.userId.trim();
    const trackId = dto.trackId.trim();
    if (!userId || !trackId) throw new BadRequestException('userId and trackId must not be blank');
    const genre = dto.genre?.trim() || undefined;
    const artist = dto.artist?.trim() || undefined;
    await this.prisma.$transaction(async tx => {
      await tx.user.upsert({ where: { id: userId }, create: { id: userId }, update: {} });
      await tx.track.upsert({
        where: { id: trackId },
        create: { id: trackId, title: dto.title?.trim() || trackId },
        update: dto.title?.trim() ? { title: dto.title.trim() } : {},
      });
      if (genre) {
        const g = await tx.genre.upsert({ where: { name: genre }, create: { name: genre }, update: {} });
        await tx.track.update({ where: { id: trackId }, data: { genreId: g.id } });
      }
      if (artist) {
        const a = await tx.artist.upsert({ where: { name: artist }, create: { name: artist }, update: {} });
        await tx.track.update({ where: { id: trackId }, data: { artistId: a.id } });
      }
      await tx.rawEvent.create({
        data: { userId, trackId, eventType: dto.eventType as EventType, genre, artist },
      });
    });
    return { accepted: true, userId, trackId, eventType: dto.eventType };
  }

  private eventWeight(type: EventType): number {
    switch (type) {
      case EventType.LIKE: return 3;
      case EventType.FOLLOW: return 4;
      case EventType.SKIP: return -1;
      default: return 1;
    }
  }

  async rebuild(requestedBy?: string) {
    // Concurrent rebuild requests may race for the same version. Retry only version collisions.
    let run: { id: string; version: number };
    for (let attempt = 0; ; attempt++) {
      const last = await this.prisma.rebuildRun.findFirst({ orderBy: { version: 'desc' }, select: { version: true } });
      const version = (last?.version ?? 0) + 1;
      try {
        run = await this.prisma.rebuildRun.create({
          data: { version, requestedBy, status: RebuildStatus.RUNNING },
        });
        break;
      } catch (error: unknown) {
        const code = (error as { code?: string })?.code;
        if (code !== 'P2002' || attempt >= 4) throw error;
      }
    }

    try {
      const events = await this.prisma.rawEvent.findMany({ orderBy: [{ createdAt: 'asc' }, { id: 'asc' }] });
      const genres = new Map<string, Counter>();
      const artists = new Map<string, Counter>();
      const tracks = new Map<string, { trackId: string; score: number; eventCount: number }>();

      const update = (map: Map<string, Counter>, userId: string, label: string, type: EventType) => {
        const k = JSON.stringify([userId, label]);
        const row = map.get(k) ?? { userId, key: label, score: 0, listenCount: 0, likeCount: 0, followCount: 0, sourceCount: 0 };
        row.score += this.eventWeight(type);
        row.sourceCount++;
        if (type === EventType.LISTEN) row.listenCount++;
        if (type === EventType.LIKE) row.likeCount++;
        if (type === EventType.FOLLOW) row.followCount++;
        map.set(k, row);
      };

      for (const event of events) {
        if (event.genre?.trim()) update(genres, event.userId, event.genre.trim(), event.eventType);
        if (event.artist?.trim()) update(artists, event.userId, event.artist.trim(), event.eventType);
        const track = tracks.get(event.trackId) ?? { trackId: event.trackId, score: 0, eventCount: 0 };
        track.score += this.eventWeight(event.eventType);
        track.eventCount++;
        tracks.set(event.trackId, track);
      }

      const genreNames = [...new Set([...genres.values()].map(x => x.key))];
      const artistNames = [...new Set([...artists.values()].map(x => x.key))];
      for (const name of genreNames) await this.prisma.genre.upsert({ where: { name }, create: { name }, update: {} });
      for (const name of artistNames) await this.prisma.artist.upsert({ where: { name }, create: { name }, update: {} });
      const [genreRows, artistRows] = await Promise.all([
        genreNames.length ? this.prisma.genre.findMany({ where: { name: { in: genreNames } } }) : [],
        artistNames.length ? this.prisma.artist.findMany({ where: { name: { in: artistNames } } }) : [],
      ]);
      const genreIds = new Map<string, string>(genreRows.map(x => [x.name, x.id] as const));
      const artistIds = new Map<string, string>(artistRows.map(x => [x.name, x.id] as const));

      const currentGenres = [...genres.values()].map(x => {
        const genreId = genreIds.get(x.key);
        if (!genreId) throw new Error(`Missing genre record for aggregate label: ${x.key}`);
        return {
          userId: x.userId, genreId, score: x.score,
          listenCount: x.listenCount, likeCount: x.likeCount, followCount: x.followCount, sourceCount: x.sourceCount,
        };
      });
      const currentArtists = [...artists.values()].map(x => {
        const artistId = artistIds.get(x.key);
        if (!artistId) throw new Error(`Missing artist record for aggregate label: ${x.key}`);
        return {
          userId: x.userId, artistId, score: x.score,
          listenCount: x.listenCount, likeCount: x.likeCount, followCount: x.followCount, sourceCount: x.sourceCount,
        };
      });
      const genreSnapshots = [...genres.values()].map(x => ({ rebuildId: run.id, userId: x.userId, genre: x.key, score: x.score, sourceCount: x.sourceCount }));
      const artistSnapshots = [...artists.values()].map(x => ({ rebuildId: run.id, userId: x.userId, artist: x.key, score: x.score, sourceCount: x.sourceCount }));
      const trackSnapshots = [...tracks.values()].map(x => ({ rebuildId: run.id, ...x }));

      const expectedGenreEvents = events.filter(e => !!e.genre?.trim()).length;
      const expectedArtistEvents = events.filter(e => !!e.artist?.trim()).length;
      if (currentGenres.reduce((n, x) => n + x.sourceCount, 0) !== expectedGenreEvents ||
          currentArtists.reduce((n, x) => n + x.sourceCount, 0) !== expectedArtistEvents ||
          trackSnapshots.reduce((n, x) => n + x.eventCount, 0) !== events.length) {
        throw new Error('Rebuild consistency validation failed; active version was not changed.');
      }

      // Save immutable versioned aggregates and switch active version atomically.
      await this.prisma.$transaction(async tx => {
        if (genreSnapshots.length) await tx.genreAffinitySnapshot.createMany({ data: genreSnapshots });
        if (artistSnapshots.length) await tx.artistAffinitySnapshot.createMany({ data: artistSnapshots });
        if (trackSnapshots.length) await tx.trackPopularitySnapshot.createMany({ data: trackSnapshots });
        // A slower older rebuild must never replace a newer successful active version.
        const active = await tx.activeAggregateVersion.findUnique({ where: { id: 1 } });
        if ((active?.version ?? 0) < version) {
          await tx.userGenreAffinity.deleteMany();
          await tx.userArtistAffinity.deleteMany();
          if (currentGenres.length) await tx.userGenreAffinity.createMany({ data: currentGenres });
          if (currentArtists.length) await tx.userArtistAffinity.createMany({ data: currentArtists });
          await tx.activeAggregateVersion.upsert({
            where: { id: 1 }, create: { id: 1, version }, update: { version },
          });
        }
        await tx.rebuildRun.update({
          where: { id: run.id },
          data: { status: RebuildStatus.SUCCEEDED, completedAt: new Date() },
        });
      });
      return this.rebuildStatus(run.id);
    } catch (error: any) {
      await this.prisma.rebuildRun.update({
        where: { id: run.id },
        data: { status: RebuildStatus.FAILED, completedAt: new Date(), error: String(error?.message ?? error).slice(0, 2000) },
      });
      throw error;
    }
  }

  async rebuildStatus(id: string) {
    const run = await this.prisma.rebuildRun.findUnique({
      where: { id },
      include: { _count: { select: { genreAffinities: true, artistAffinities: true, trackPopularities: true } } },
    });
    if (!run) throw new NotFoundException('Rebuild run not found');
    return run;
  }

  async activeVersion() {
    return (await this.prisma.activeAggregateVersion.findUnique({ where: { id: 1 } })) ?? { id: 1, version: 0, updatedAt: null };
  }

  async aggregates(userId?: string) {
    const active = await this.activeVersion();
    if (!active.version) return { version: 0, genres: [], artists: [], popularity: [] };
    const run = await this.prisma.rebuildRun.findUnique({ where: { version: active.version } });
    if (!run || run.status !== RebuildStatus.SUCCEEDED) return { version: active.version, genres: [], artists: [], popularity: [] };
    const [genres, artists, popularity] = await Promise.all([
      this.prisma.genreAffinitySnapshot.findMany({ where: { rebuildId: run.id, ...(userId ? { userId } : {}) }, orderBy: [{ score: 'desc' }, { genre: 'asc' }] }),
      this.prisma.artistAffinitySnapshot.findMany({ where: { rebuildId: run.id, ...(userId ? { userId } : {}) }, orderBy: [{ score: 'desc' }, { artist: 'asc' }] }),
      this.prisma.trackPopularitySnapshot.findMany({ where: { rebuildId: run.id }, orderBy: [{ score: 'desc' }, { trackId: 'asc' }] }),
    ]);
    return { version: active.version, genres, artists, popularity };
  }

  async rollback(version: number) {
    if (!Number.isInteger(version) || version < 1) throw new BadRequestException('Version must be a positive integer');
    const run = await this.prisma.rebuildRun.findUnique({ where: { version } });
    if (!run || run.status !== RebuildStatus.SUCCEEDED) throw new BadRequestException('Target version does not exist or did not succeed');
    await this.prisma.activeAggregateVersion.upsert({ where: { id: 1 }, create: { id: 1, version }, update: { version } });
    return { activeVersion: version, rolledBackTo: run.id };
  }

  async userAffinities(userId: string) {
    // Read from the active immutable version so rollback changes every read path consistently.
    const active = await this.activeVersion();
    if (!active.version) return { userId, version: 0, genres: [], artists: [] };

    const run = await this.prisma.rebuildRun.findUnique({ where: { version: active.version } });
    if (!run || run.status !== RebuildStatus.SUCCEEDED) {
      return { userId, version: active.version, genres: [], artists: [] };
    }

    const [genres, artists] = await Promise.all([
      this.prisma.genreAffinitySnapshot.findMany({
        where: { rebuildId: run.id, userId },
        orderBy: [{ score: 'desc' }, { genre: 'asc' }],
      }),
      this.prisma.artistAffinitySnapshot.findMany({
        where: { rebuildId: run.id, userId },
        orderBy: [{ score: 'desc' }, { artist: 'asc' }],
      }),
    ]);
    return {
      userId,
      version: active.version,
      genres: genres.map(({ rebuildId, ...item }) => item),
      artists: artists.map(({ rebuildId, ...item }) => item),
    };
  }

  async createSnapshot(dto: CreateSnapshotDto) {
    await this.prisma.user.upsert({ where: { id: userId }, create: { id: userId }, update: {} });
    const uniqueTrackIds = new Set(dto.items.map(x => x.trackId));
    if (uniqueTrackIds.size !== dto.items.length) throw new BadRequestException('Snapshot cannot contain duplicate trackId values');
    for (const item of dto.items) {
      await this.prisma.track.upsert({ where: { id: item.trackId }, create: { id: item.trackId, title: item.trackId }, update: {} });
    }
    const ttlHours = dto.ttlHours ?? 24;
    const expiresAt = new Date(Date.now() + ttlHours * 60 * 60 * 1000);
    return this.prisma.recommendationSnapshot.create({
      data: {
        userId, algorithmVersion: dto.algorithmVersion?.trim() || 'v1', expiresAt,
        items: { create: items.map((item, position) => ({ trackId: item.trackId, position, score: item.score })) },
      },
      include: { items: { include: { track: true }, orderBy: { position: 'asc' } } },
    });
  }

  async getSnapshot(id: string) {
    const snapshot = await this.prisma.recommendationSnapshot.findUnique({
      where: { id }, include: { items: { include: { track: true }, orderBy: { position: 'asc' } } },
    });
    if (!snapshot) throw new NotFoundException('Snapshot not found');
    if (snapshot.expiresAt <= new Date()) throw new NotFoundException('Snapshot has expired');
    return snapshot;
  }

  async getUserSnapshots(userId: string) {
    return this.prisma.recommendationSnapshot.findMany({
      where: { userId, expiresAt: { gt: new Date() } },
      include: { items: { include: { track: true }, orderBy: { position: 'asc' } } },
      orderBy: { generatedAt: 'desc' },
    });
  }

  async cleanupSnapshots() {
    const result = await this.prisma.recommendationSnapshot.deleteMany({ where: { expiresAt: { lte: new Date() } } });
    return { deletedSnapshots: result.count };
  }
}
