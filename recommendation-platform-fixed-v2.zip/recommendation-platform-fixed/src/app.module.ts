import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { RecommendationsModule } from './recommendations/recommendations.module';

@Module({
  imports: [PrismaModule, RecommendationsModule],
})
export class AppModule {}
